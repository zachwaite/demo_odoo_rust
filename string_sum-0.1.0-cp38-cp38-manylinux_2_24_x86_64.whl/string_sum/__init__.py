from .string_sum import *

__doc__ = string_sum.__doc__
